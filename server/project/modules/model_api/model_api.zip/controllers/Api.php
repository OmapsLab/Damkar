<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Api extends CI_Controller {


	public function __construct() {
		parent::__construct();
		$this->load->model('db_restoran');
		$this->load->model('db_menu');
	}

	public function restoran() {
		$restoran = $this->db_restoran->view();
		foreach ($restoran->result() as $row) {
			$col['id_restoran'] = $row->id_restoran;
			$col['telp'] = $row->telp;
			$col['nama'] = $row->nama;
			$col['alamat'] = $row->alamat;
			$col['latitude'] = $row->latitude;
			$col['longitude'] = $row->longitude;
			$restoran_list[] = $col;
		}

		$restoran_data = ($restoran_list) ? $restoran_list : array();
		header('Content-Type: application/json');
		echo json_encode($restoran_data);
	}

	public function all_data() {
		$restoran = $this->db_restoran->view();
		foreach ($restoran->result() as $row) {
			$id_restoran = $row->id_restoran;
			$menu = $this->db_menu->view_by_id_restoran($id_restoran);
			
			$col['id_restoran'] = $row->id_restoran;
			$col['telp'] = $row->telp;
			$col['nama'] = $row->nama;
			$col['alamat'] = $row->alamat;
			$col['latitude'] = $row->latitude;
			$col['longitude'] = $row->longitude;
			if (@$menu->row()->id_restoran == $id_restoran) {
				$col['menu'] = $menu->result();	
			} else {
				$col['menu'] = array();
			}
			
			$restoran_list[] = $col;
		}

		$restoran_data = ($restoran_list) ? $restoran_list : array();
		header('Content-Type: application/json');
		echo json_encode($restoran_data);
	}

	public function menu() {

	}

}