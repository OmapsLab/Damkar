<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Db_restoran extends CI_Model {

	public function view() {
		return $this->db->query("SELECT *
							     FROM restoran 
							     ORDER BY id_restoran DESC");	
	}

	public function view_by_id($id) {
		return $this->db->query("SELECT *
							     FROM restoran 
							     WHERE id_restoran = '".$id."' ");	
	}

	public function add($nama, $alamat, $telp, $lat, $long, $foto) {
		return $this->db->query("INSERT INTO restoran ( nama,
														alamat,
														telp,
														latitude,
														longitude,
														foto )
								 VALUES ( '".$nama."',
								 		  '".$alamat."',
								 		  '".$telp."',
								 		  '".$lat."',
								 		  '".$long."',
								 		  '".$foto."')");	
	}

	public function update($id, $nama, $alamat, $telp, $lat, $long, $foto) {
		return $this->db->query("UPDATE restoran SET nama = '".$nama."',
														alamat = '".$alamat."',
														telp = '".$telp."',
														latitude = '".$lat."',
														longitude = '".$long."',
														foto = '".$foto."'
								 WHERE id_restoran = '".$id."'");	
	}

	public function delete($id) {
		return $this->db->query("DELETE 
							     FROM restoran 
								 WHERE id_restoran = '".$id."'");	
	}
}
