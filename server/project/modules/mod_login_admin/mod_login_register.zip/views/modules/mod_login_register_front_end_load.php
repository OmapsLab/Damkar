<div class="row" id="login-register-menu">
	<div class="span3">
    	<h4>Login<hr></h4>
    	<label>Isi Username / Email dan password Kamu untuk Login</label>
    	<div>
	    	<form id="user-front-end-login" method="post" action="<?=base_url()?>index.php/mod_login/login_attempt" onsubmit="return loginAttempt()">
    		<table>
    			<tr>
    				<td><div id="box-alert"></div></td>
    			</tr>
    			<tr>
    				<td><input name="email" placeholder="Email" type="text"/></td>
    			</tr>
    			<tr>
    				<td><input name="pass" placeholder="Password" type="password"/></td>
    			</tr>
    			<tr>
    				<td align="right"><button class="btn btn-success">Login</button></td>
    			</tr>
    			<tr valign="bottom">
    				<td align="right">
    					<ul class="nav nav-pills">
    						<li><a id="forgot-password-action" onclick="showEmailForgotPass()" href="#">Lupa Password..?</a></li>
	    				</ul>
	    			</td>
	    		</tr>
	    	</table>
    		</form>
    	</div>
    </div>
    <div class="pading-left-right-7 span3">
    	<h4>Login with Facebook<hr></h4>
    	<label>Atau Login dengan Facebook</label>
    	<a href="{SITE_INDEX}mod_login/login_with_facebook"><img width="220" src="{IMAGES}facebook-connect-button.png"/></a>	
    </div>
    <div class="login-register-left-pos span3">
	 	<h4>Daftar<hr></h4>
	    <label>Untuk mendaftar, masukan alamat email Kamu untuk menjadi member Kami</label>
	    <div>
	    	<form action="">
		    	<table>
		    		<tr>
		    			<td><div id="box-alert-register"></div></td>
		    		</tr>
		    		<tr>
		    			<td>
		    				<input id="email-register" name="email" placeholder="Masukan Email Kamu" type="text"/>
		    			</td>
		    		</tr>
		    		<tr>
		    			<td align="right"><a id="register-action-complete" onclick="showRegisterContinueField()" class="btn btn-success">Daftar</a></td>
		    		</tr>
		    	</table>
	    	</form>
	    </div>
    </div>
    <br>
</div>
<div id="show-register-fields" style="display:none; margin-bottom: 50px;">
	<?=form_open('mod_login/register_attempt','id="user-front-end-register" onsubmit="return registerAttempt()"')?>
	<table border="0" width="100%">
		<tr>
	    	<td colspan="2"><div id="box-alert-reg"></div></td>
	    </tr>
		<tr>
	    	<td colspan="2"><h4>Detail Pendaftaran<hr></h4></td>
	    </tr>
	    <tr valign="top">
	    	<td width="260"><input type="text" name="full_name" placeholder="Nama Lengkap"/></td>
	    	<td valign="top" rowspan="7">
	    		<div>
	    			<h5>Info(Harap dibaca dulu)</h5>
	    			<div>
	    				Untuk pengisian Alamat Harus lengkap.<br>
	    				Format Penulisanya : <br>
	    				<i><b>Dareah, Rt/Rw, Kecamatan, Kabupaten, Kota, Provinsi</b></i><br>
	    				Karena alamat ini akan kami gunakan untuk :<br>
	    				<ul>
	    					<li>Pengecekan biaya pengiriman</li> 
	    					<li>Dan kemana barang akan kita kirim</li>
	    				</ul> 
	    				Jadi harus lengkap ya :) 
	    			</div>
	    		</div>
	    	</td>
	    </tr>
	    <tr valign="top">
	    	<td><input type="text" name="hp" placeholder="No Hp"/></td>
	    </tr>
	    <tr valign="top">
	    	<td><textarea name="alamat" cols="60" placeholder="Alamat Lengkap Format: Daerah, Rt/Rw, Kecamatan, Kabupaten, Kota, Provinsi "></textarea></td>
	    </tr>
	    <tr>
	    	<td><hr style="width: 200px;"></td>
	    </tr>
	    <tr>
	    	<td><input type="password" name="pass" placeholder="Password"/></td>
	    </tr>
	    <tr>
	    	<td><input id="email-register-hidden" type="hidden" name="email-register-hidden" placeholder="Password"/></td>
	    </tr>
	    <tr>
	    	<td><input id="register-action-complete-continue" class="btn btn-primary" type="submit" value="Daftar"/></td>
	    </tr>
	</table>
	<?=form_close()?>
</div>
<div id="show-forgot-password-fields" style="display:none; margin-bottom: 50px;">
	<?=form_open('mod_login/register_attempt_')?>
	<table border="0" width="100%">
		<tr>
	    	<td>
	    		<h1>Reset Password<hr></h1>
	    		<div><p>Kami akan segera mengirimkan email reset password ke email kamu.<br> Jadi isi field email ini dengan benar ya.</p></div>
	    		<div id="box-alert-reg"></div>
	    		<div>
	    			<ul style="list-style: none;">
	    				<li><input type="text" name="email" placeholder="Isi Email Kamu Terlebih dahulu"/></li>
	    				<li><a href="javascript:;" class="btn btn-primary">Kirim</a></li>
	    			</ul>
	    		</div>
	    	</td>
	    </tr>
		<tr>
	    	<td></td>
	    </tr>
	</table>
	<?=form_close()?>
</div>