<div class="login-register-reg-success" align="left">
	<h1>Registrasi Sukses<hr></h1>
	<p>
		Selamat Kamu telah berhasil melakukan Registrasi.<br>
		Aktifkan segera Akun Kpopstar-mu dengan cara :
		<ul>
			<li>Cek inbox/spam Email Kamu</li>
			<li>Cari Subject Email <b>Kpopstar Registration Confrim</b></li>
			<li>Ikuti petunjuk di dalam email</li>
			<li>Jika terjadi masalah segera hubungi Admin di facebook Chat / Contact +6281321759801</li>
			<li>Kami akan selalu memandumu</li>
		</ul>
	</p>
</div>