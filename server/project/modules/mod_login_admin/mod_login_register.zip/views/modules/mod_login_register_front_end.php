<script type="text/javascript">$(document).ready(function(){$("#login-register-menu").hide();$("#base-area-box-alert").hide();$("#show-register-fields").hide();});</script>
<div id="show-mod-login-register-front-end">
	<?php if (isset($sess_user_id) || get_access_login('logged_user_id_front_end') == true) {?>
	<div id="login-register-search-menu-header">
		<div id="base-area-user-login-search">
			<ul>
				<li><button class="btn btn-inverse">Welcome Kpopers</button></li>
				<li><input class="input-size-wide" name="search" type="text" placeholder="<?=$user_name?>, Apa yang ingin kamu cari?"/></li>
				<li><a class="btn btn-inverse "><i class="icon-search icon-white"></i> Cari</a></li>
			</ul>
		</div>
	</div>
	<?php } else {?>
	<div id="login-register-search-menu-header">
		<div id="base-area-user-login-search">
			<ul>
				<li><button id="login-action" onclick="showLoginRegisterField('login-action')" class="btn btn-success "><i class="icon-user icon-white "></i> Login</button></li>
				<li><button id="register-action" onclick="showLoginRegisterField('register-action')" class="btn btn-primary ">Register</button></li>
				<li><input class="input-size-wide2" name="search" type="text" placeholder="Ketik apa yang ingin kamu cari"/></li>
				<li><button class="btn btn-inverse "><i class="icon-search icon-white"></i> Cari</button></li>
			</ul>
		</div>
	</div>
	<div id="login-register-search-menu-header-load"></div>
	<?php }?>
</div>