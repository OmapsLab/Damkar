<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mod_login extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('db_order');
	}

	public function index() {
		$this->omap->type('modules', 'mod_login');
	}

	public function login_with_facebook() {
		$user_data = fb_get_user_data();
		//var_dump($user_data);
		
		if ($user_data != "") {
			$email = htmlspecialchars($user_data['email']);
			$full_name = htmlspecialchars($user_data['name']);
			$no_hp = htmlspecialchars("");
			$alamat = htmlspecialchars($user_data['location']['name']);
			$pass = MD5($user_data['username']);
			$pass_ori = $user_data['username'];

			// Cek in database
			$query = $this->db->query("SELECT * FROM `ad_user` WHERE email = '".$email."'");
			@$db_user_id = $query->row()->id_user;
			@$db_user_name = $query->row()->nama;
			@$db_user_email = $query->row()->email;

			if ($email == $db_user_email) {
				$this->session->set_userdata('logged_user_id_front_end', $db_user_id);
				$this->session->set_userdata('logged_user_name_front_end', $db_user_name);
				$query = $this->db->query("UPDATE `ad_user` SET status='online', online_date = NOW() WHERE id_user = '".$db_user_id."'");
				redirect(SITE);
			} else {
				$this->db->query("INSERT INTO `ad_user`(nama, alamat, hp, email, pass, join_date) VALUES ('".$full_name."', '".$alamat."', '".$no_hp."', '".$email."', '".$pass."', NOW())");
				$user_id =  $this->db->insert_id();
				$this->session->set_userdata('logged_user_id_front_end', $user_id);
				$this->session->set_userdata('logged_user_name_front_end', $full_name);
				$query = $this->db->query("UPDATE `ad_user` SET status='online', online_date = NOW() WHERE id_user = '".$user_id."'");
				redirect(SITE);
			}
		} else {
			$login_url = fb_get_login_url();
			redirect($login_url);
		}
	}

	public function load_login_register_field() {
		$this->omap->type('modules');
		$this->omap->display('mod_login_register_front_end_load');
	}

	public function prosess() {
		$email = $this->input->post('email');
		$no_customer = $this->input->post('no_customer');
		$query = $this->db->query("SELECT * FROM `ad_user` WHERE email = '".$email."'");
		@$db_email = $query->row()->email;
		@$db_no_customer = $query->row()->no_customer;
		@$db_user = $query->row()->nama;
		@$submit = $this->input->post('submit');

		if ($submit == 'Register') {
			redirect('mod_register');
		} else {
			if ($email == "" || $no_customer == "") {
				redirect('mod_login?n=err_null');
			} else if ($email != $db_email) {
				redirect('mod_login?n=err_email');
			} else if ($no_customer != $db_no_customer) {
				redirect('mod_login?n=err_no_customer');
			} else {
				$this->session->set_userdata('logged', $no_customer);
				$this->session->set_userdata('logged_user', $db_user);
				redirect('order');
			}
		}
	}

	public function logout(){
		redirect('mod_login');
	}

	public function logout_front_end(){
		$session_name = $this->input->get('session_name');
		$this->session->unset_userdata($session_name);
		redirect(base_url());
	}

	public function login_register_front_end() {
		extract(get_modules_access_data($this->input->get('modules_data')));
		if (isset($sess_user_id) || $this->session->userdata('logged_user_id_front_end')) {
			$data['user_id'] = isset_switch(@$sess_user_id, $this->session->userdata('logged_user_id_front_end'));
			$data['user_name'] = isset_switch(@$sess_user_name, $this->session->userdata('logged_user_name_front_end'));
			$this->omap->type('modules');
			$this->omap->title('Login Area');
			$this->omap->display('mod_login_register_front_end', $data);
		} else {
			$this->omap->type('modules');
			$this->omap->title('Login Area');
			$this->omap->display('mod_login_register_front_end');
		}
	}

	public function login_attempt() {
		$email = htmlspecialchars($this->input->post('email'));
		$pass = MD5($this->input->post('pass'));
		$query = $this->db->query("SELECT * FROM `ad_user` WHERE email = '".$email."'");
		@$db_email = $query->row()->email;
		@$db_user_id = $query->row()->id_user;
		@$db_user_name = $query->row()->nama;
		@$db_pass = $query->row()->pass;

		if ($email == "" || $pass == "") {
			echo '{"status":"err_null", "message":"Field Masih Kosong!!"}';
		} else if ($email != $db_email) {
			echo '{"status":"err_email", "message":"Email Belum Terdaftar!!"}';
		} else if ($pass != $db_pass) {
			echo '{"status":"err_pass", "message":"Password Salah!!"}';
		} else {
			$this->session->set_userdata('logged_user_id_front_end', $db_user_id);
			$this->session->set_userdata('logged_user_name_front_end', $db_user_name);
			$query = $this->db->query("UPDATE `ad_user` SET status='online', online_date = NOW() WHERE id_user = '".$db_user_id."'");
			echo '{"status":"ss", "message":"Suksess"}';
		}
	}

	public function register_attempt() {
		$email = htmlspecialchars($this->input->post('email-register-hidden'));
		$full_name = htmlspecialchars($this->input->post('full_name'));
		$no_hp = htmlspecialchars($this->input->post('hp'));
		$alamat = htmlspecialchars($this->input->post('alamat'));
		$pass = MD5($this->input->post('pass'));
		$pass_ori = $this->input->post('pass');

		// Generate No customer
		$no_customer = substr(number_format(time() * rand(),0,'',''),0,4);

		// Cek in database
		$query = $this->db->query("SELECT * FROM `ad_user` WHERE email = '".$email."'");
		@$db_email = $query->row()->email;

		if ($email == "" || $full_name == "" || $no_hp == "" || $alamat == "" || $pass == "") {
			echo '{"status":"err_null", "message":"Field Masih Kosong!!"}';
		} else if ($email == $db_email) {
			echo '{"status":"err_null", "message":"Email sudah pernah terdaftar!!"}';
		} else if (number_match($no_hp)){
			echo '{"status":"err_phone", "message":"No Hp Harus Angka"}';
		} else {
			$this->db->query("INSERT INTO `ad_user`(nama,alamat,hp,email,pass,no_customer,join_date) VALUES ('".$full_name."', '".$alamat."', '".$no_hp."', '".$email."', '".$pass."', '".$no_customer."', NOW())");

			$email_sender = 'kpop.star.suju.shop@gmail.com';
			$email_user = 'kpop.star.suju.shop';
			$email_pass = 'kshop@omap';
			$config = Array( 'protocol' => 'smtp', 'smtp_host' => 'ssl://smtp.googlemail.com', 'smtp_port' => 465, 'smtp_user' => $email_user, 'smtp_pass' => $email_pass, 'mailtype' => 'html', 'charset' => 'iso-8859-1' );
			$this->load->library('email', $config);
			$content_email = $this->mail_register_send($full_name, SITE_INDEX.'register/confirm?e='.base64_encode($email).'&esp='.md5($pass_ori));
			$this->email->set_newline("\r\n");
			$this->email->from($email_sender, 'Kpopstar');
			$this->email->to($email);
			$this->email->subject('Kpopstar Registration Confrim');
			$this->email->message($content_email);
			$result = $this->email->send();
			$this->email->print_debugger();
			echo '{"status":"ss", "message":"Sukses"}';
		}
	}

	public function send_email_reset() {
		$email = $this->input->get('email');
		$email_encode = base64_encode($email);

		$email_sender = 'kpop.star.suju.shop@gmail.com';
		$email_user = 'kpop.star.suju.shop';
		$email_pass = 'kshop@omap';
		$config = Array( 'protocol' => 'smtp', 'smtp_host' => 'ssl://smtp.googlemail.com', 'smtp_port' => 465, 'smtp_user' => $email_user, 'smtp_pass' => $email_pass, 'mailtype' => 'html', 'charset' => 'iso-8859-1' );
		$this->load->library('email', $config);
		$content_email = $this->mail_register_send($full_name, rawurlencode(SITE_INDEX.'register/confirm?e='.base64_encode($email).'&esp='.md5($pass_ori)));
		$this->email->set_newline("\r\n");
		$this->email->from($email_sender, 'Kpopstar');
		$this->email->to($email);
		$this->email->subject('Kpopstar Reset Password');
		$this->email->message($content_email);
		$result = $this->email->send();
		$this->email->print_debugger();
		echo '{"status":"ss", "message":"Sukses"}';


	}

	private function mail_register_send($name, $link) {
		return
		'<div>
			<h1>KONFIRMASI REGISTRASI</h1>
			<div>
				Hay '.$name.', Selamat Kamu telah berhasil melakukan Regitrasi.<br>
				Untuk melakukan Konfirmasi Registrasi klik link dibawah ini :<br>
				<p><a href='.$link.'>'.$link.'</a></p>
				Terima Kasih<br>
				Kpopstar Team
			</div>		
		</div>';
	}

	private function mail_resspass_send($name, $link) {
		return
		'<div>
			<h1>RESET PASSWORD</h1>
			<div>
				Hay '.$name.', Untuk melakukan mendapatkan password yang baru klik link dibawah ini.<br>
				<p><a href='.$link.'>'.$link.'</a></p>
				Terima Kasih<br>
				Kpopstar Team
			</div>		
		</div>';
	}


	public function register_success() {
		$this->omap->type('modules');
		$this->omap->display('mod_login_register_front_end_register_success');
	}

}