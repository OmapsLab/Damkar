<div>
	<h1><?=$source_name?><hr></h1>
	<?=$source_description?>.<br>
	<div style="margin-bottom: 10px;">Developer by <?=$developer_name?>, Email (<?=$developer_email?>)</div>
	<div style="margin-bottom: 10px;">This theme is Sample. You can Change like your think.</div>
</div>

 