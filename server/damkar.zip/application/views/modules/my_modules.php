<div>
	<div>
		<h1>Omaps-CI Versions<hr></h1>
		<?=$version?>
	</div>
	<div>
		<h1>Logo<hr></h1>
		<img src="{IMAGES}<?=$logo?>"/>
	</div>
	<div>
		<h1>How its work<hr></h1>
		<img src="{IMAGES}<?=$structure?>" width="500"/>
	</div>
	<div>
		<h1>Retrieve from pages testing<hr></h1>
		<?=$dasbor_data?>
	</div>
</div>
