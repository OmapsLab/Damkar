<div class="row-fluid">
    <div class="block">
        <div class="block-heading">
            <span class="block-icon pull-right">
                <a href="#" class="demo-cancel-click" rel="tooltip" title="Click to refresh"><i class="icon-refresh"></i></a>
            </span>

            <a href="#widget2container" data-toggle="collapse">Laporan Kebakaran</a>
        </div>
        <div id="widget2container" class="block-body collapse in">
           <div class="span6">
           		
           </div>
           <div class="span6">
           		
           </div>
        </div>
    </div>
</div>
<div class="row-fluid">
    <div class="block">
        <div class="block-heading">
            <span class="block-icon pull-right">
                <a href="#" class="demo-cancel-click" rel="tooltip" title="Click to refresh"><i class="icon-refresh"></i></a>
            </span>

            <a href="#widget2container" data-toggle="collapse">Maps</a>
        </div>
        <div id="widget2container" class="block-body collapse in">
           {MAPS}
        </div>
    </div>
</div>