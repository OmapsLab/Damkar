<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Api extends CI_Controller {


	public function __construct() {
		parent::__construct();
		$this->load->model('db_pengaduan');
	}
	
	public function create_pengaduan($hp, $lat, $long) {
		$id_masyarakat = $this->db_pengaduan->add_pengaduan_masyarakat($hp);
		$id_peta = $this->db_pengaduan->add_pengaduan_peta($lat, $long);
		$this->db_pengaduan->add_pengaduan($id_masyarakat, $id_peta);
	}

}